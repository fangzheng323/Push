# iOS10APNSTest
iOS 10中APNS的推送测试
#### 1、添加action
![添加action](http://og0h689k8.bkt.clouddn.com/public/16-12-2/16114429.jpg)

#### 2、添加视频

![视频添加](http://og0h689k8.bkt.clouddn.com/public/16-12-2/79727477.jpg)

#### 3、添加gif
![git展示](http://og0h689k8.bkt.clouddn.com/public/16-12-2/40286074.jpg)

#### 4、添加图片
![图片添加](http://og0h689k8.bkt.clouddn.com/public/16-12-2/34021870.jpg)

